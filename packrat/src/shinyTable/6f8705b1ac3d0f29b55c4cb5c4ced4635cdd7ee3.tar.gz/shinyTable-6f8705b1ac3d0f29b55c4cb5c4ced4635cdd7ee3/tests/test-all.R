library(testthat)
test_package("shinyTable")