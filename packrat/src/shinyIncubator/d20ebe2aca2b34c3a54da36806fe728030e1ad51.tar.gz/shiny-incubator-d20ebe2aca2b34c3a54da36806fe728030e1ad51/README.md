shiny-incubator
===============

Examples and ideas that don't belong in the core Shiny package and aren't officially supported.

To install, install the `devtools` package if necessary (`install.packages("devtools")`) and run:

```
devtools::install_github("shiny-incubator", "rstudio")
```
